﻿using System;
using System.Collections.Generic;
using System.Text;

namespace TicTacToe
{
    enum GameState
    {
        GameStart,
        Playerturn,
        PCturn,
        GameOver

    }
}
