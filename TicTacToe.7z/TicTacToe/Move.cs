﻿using System;
using System.Collections.Generic;
using System.Text;

namespace TicTacToe
{
    /// <summary>
    /// this class could've been a tuple
    /// </summary>
    class Move
    {
        int x { get; set; }
        int y { get; set; }
    }
}
