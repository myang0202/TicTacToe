﻿using System;
using System.Collections.Generic;
using System.Text;
using TicTacToe.Interfaces;

namespace TicTacToe
{
    class OutputManager:IOutputManager
    {
        public void WriteLine()
        {
            new NotImplementedException();
        }
    }
}
