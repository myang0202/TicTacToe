﻿using System;
using System.Collections.Generic;
using System.Text;

namespace TicTacToe.Interfaces
{
    interface IOutputManager
    {
    }
}
