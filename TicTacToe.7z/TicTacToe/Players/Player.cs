﻿using System;
using System.Collections.Generic;
using System.Text;
using TicTacToe.Interfaces;

namespace TicTacToe.Players
{
    class Player :IPlayer
    {
        String name { get; set; }
    }
}
