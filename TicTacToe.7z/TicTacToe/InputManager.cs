﻿using System;
using System.Collections.Generic;
using System.Text;
using TicTacToe.Interfaces;

namespace TicTacToe
{

    class InputManager:IInputManager
    {
        /// <summary>
        /// gets input from user
        /// </summary>
        public void ReadLine()
        {
            new NotImplementedException();
        }
    }
}
